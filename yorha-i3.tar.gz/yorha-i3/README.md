# YoRHa i3: Fedora i3 respin with a NieR desktop and NieR login screen

A lighter alternative to the KDE version, which suits a 4 GB laptop better. It builds a
bootable Fedora i3 live ISO with:

- **NieR login screen** (custom SDDM theme): clock, "UNIT_ID / ACCESS_CODE / SESSION" panel,
  power buttons and a HUD-style header, using the NieR menu palette (cream and dark brown)
- **i3** with that palette on windows and bar, small gaps, and a rofi launcher
- **conky HUD** on the left of the desktop (BUNKER_LINK, CPU/RAM/battery bars)
- kitty terminal, dunst notifications, picom, feh wallpaper

## Files

- `build-iso.sh`: builds the ISO (run on Fedora)
- `yorha-i3.ks`: kickstart recipe (Fedora i3 spin plus packages)
- `payload/`: everything copied into the image (i3, conky, rofi, kitty... in `/etc/skel`,
  login theme in `/usr/share/sddm/themes/yorha`)
- `assets/default-wallpaper.png`: fallback wallpaper. Put your own at `assets/wallpaper.png`
  and it is used for both the desktop and the login screen.

Note: `payload/config/` and `payload/sddm/` are from an earlier, separate i3 attempt that was
already in this folder. They are not used by this build (only `payload/etc` and `payload/usr` are).

## Build

```
sudo setenforce 0        # livecd-creator generally needs this while building
chmod +x build-iso.sh
./build-iso.sh           # or FEDORA_VER=43 ./build-iso.sh
```

The ISO appears in `~/yorha-i3-build/fedora-kickstarts/`. Flash it with Fedora Media Writer
or copy it to your Ventoy USB.

## Using it

- On the live ISO the login screen appears first. The `liveuser` account has no password,
  so just press Enter (or click AUTHENTICATE).
- Keys: `Super+Enter` terminal, `Super+d` launcher, `Super+Shift+q` close window,
  `Super+1..9` workspaces, `Super+Shift+x` lock, `Super+Shift+e` exit.

## Preview the login theme on an installed system (optional)

```
sudo dnf install sddm qt6-qtdeclarative
sddm-greeter-qt6 --test-mode --theme /usr/share/sddm/themes/yorha
```

## Honest status

- **Not test-built.** I could not run Fedora's ISO build or SDDM here, and I could not
  render the login theme (no Qt in my sandbox). The scripts pass syntax checks and the
  payload round-trips, but expect to fix small things on the first build or first boot.
  If the login screen looks off or fails to load, send me a photo or the output of
  `journalctl -b -u sddm` and I will fix the QML.
- The font is JetBrains Mono. NieR's FOT-Rodin is not free to redistribute.
- Fedora's i3 spin still ships LightDM; the build disables it and enables SDDM instead.
