# YoRHa i3: Fedora i3 live respin with a NieR-style desktop and a NieR login screen (SDDM).
# build-iso.sh copies this next to the Fedora kickstarts and appends a generated %post section
# that embeds the config payload. Do not run this file directly.

%include fedora-live-i3.ks

# Required: the build should fail loudly if these are missing.
%packages
sddm
qt6-qtdeclarative
qt6-qtsvg
conky
picom
rofi
feh
kitty
dunst
i3lock
jetbrains-mono-fonts
%end

# Optional extras: skipped quietly if a package name differs on your Fedora version.
%packages --ignoremissing
sddm-x11
network-manager-applet
brightnessctl
pavucontrol
cava
curl
tar
git
%end
