import QtQuick 2.15
import QtQuick.Controls 2.15

// YoRHa login screen for SDDM (NieR:Automata menu look).
// Uses only plain QtQuick + Controls 2 so it works with the Qt5 and Qt6 greeters.
Rectangle {
    id: root
    width: 1920
    height: 1080
    color: "#1c1b18"

    readonly property color cream: "#d1cdb7"
    readonly property color dark: "#4a4640"
    readonly property color mid: "#8e8a78"
    readonly property color alert: "#b94a3a"
    readonly property string mono: "JetBrains Mono"

    // Scale everything from a 1920x1080 design so small laptop screens still fit.
    readonly property real u: Math.max(0.55, Math.min(width / 1920, height / 1080))

    property bool busy: false
    property string status: ""
    property date now: new Date()

    function doLogin() {
        if (root.busy)
            return
        root.busy = true
        root.status = "AUTHENTICATING..."
        sddm.login(userBox.currentText, pass.text, sessionBox.currentIndex)
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: root.now = new Date()
    }

    Connections {
        target: sddm
        function onLoginSucceeded() {
            root.status = "ACCESS GRANTED"
        }
        function onLoginFailed() {
            root.busy = false
            root.status = "AUTH_FAILED: ACCESS DENIED"
            pass.text = ""
            pass.forceActiveFocus()
        }
    }

    // ---------------------------------------------------------------- background
    Image {
        anchors.fill: parent
        source: "background.png"
        fillMode: Image.PreserveAspectCrop
    }

    Rectangle {
        anchors.fill: parent
        color: "#000000"
        opacity: 0.42
    }

    // ---------------------------------------------------------------- HUD (top-left, decorative)
    Column {
        x: 56 * root.u
        y: 48 * root.u
        spacing: 4 * root.u

        Text {
            text: "BUNKER_LINK : ESTABLISHED [ - ]"
            color: root.cream
            font.family: root.mono
            font.pixelSize: Math.round(15 * root.u)
            font.bold: true
        }
        Text {
            text: "UNIT_ID     : 2B_MODEL_S"
            color: root.mid
            font.family: root.mono
            font.pixelSize: Math.round(13 * root.u)
        }
        Text {
            text: "POD_PROG    : A140: GRAVITY"
            color: root.mid
            font.family: root.mono
            font.pixelSize: Math.round(13 * root.u)
        }
        Text {
            text: "STATUS      : AWAITING_AUTH..."
            color: root.mid
            font.family: root.mono
            font.pixelSize: Math.round(13 * root.u)
        }
    }

    // ---------------------------------------------------------------- clock (left)
    Item {
        id: clockBox
        x: 56 * root.u
        anchors.verticalCenter: parent.verticalCenter
        width: 560 * root.u
        height: 220 * root.u

        Rectangle {
            id: timeBadge
            width: timeText.implicitWidth + 56 * root.u
            height: timeText.implicitHeight + 20 * root.u
            color: root.cream

            Text {
                id: timeText
                anchors.centerIn: parent
                text: Qt.formatTime(root.now, "hh:mm")
                color: root.dark
                font.family: root.mono
                font.pixelSize: Math.round(96 * root.u)
                font.bold: true
            }
        }

        Text {
            anchors.top: timeBadge.bottom
            anchors.topMargin: 14 * root.u
            text: Qt.formatDate(root.now, "dddd, d MMMM yyyy").toUpperCase()
            color: root.cream
            font.family: root.mono
            font.pixelSize: Math.round(22 * root.u)
        }
    }

    // ---------------------------------------------------------------- login panel
    Rectangle {
        id: panel
        width: 520 * root.u
        height: header.height + body.height + 40 * root.u
        anchors.verticalCenter: parent.verticalCenter
        anchors.right: parent.right
        anchors.rightMargin: 120 * root.u
        color: root.cream
        border.color: root.dark
        border.width: 3

        Rectangle {
            id: header
            width: parent.width
            height: 44 * root.u
            color: root.dark

            Rectangle {
                id: marker
                width: 12 * root.u
                height: 12 * root.u
                rotation: 45
                color: root.cream
                anchors.verticalCenter: parent.verticalCenter
                x: 18 * root.u
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                anchors.left: marker.right
                anchors.leftMargin: 16 * root.u
                text: "YoRHa // UNIT AUTHENTICATION"
                color: root.cream
                font.family: root.mono
                font.pixelSize: Math.round(15 * root.u)
                font.bold: true
            }
        }

        Column {
            id: body
            anchors.top: header.bottom
            anchors.topMargin: 24 * root.u
            anchors.horizontalCenter: parent.horizontalCenter
            width: parent.width - 56 * root.u
            spacing: 10 * root.u

            Text {
                text: "UNIT_ID"
                color: root.dark
                font.family: root.mono
                font.pixelSize: Math.round(12 * root.u)
                font.bold: true
            }

            NierCombo {
                id: userBox
                width: parent.width
                scaleU: root.u
                darkColor: root.dark
                creamColor: root.cream
                fontFamily: root.mono
                model: userModel
                textRole: "name"
                currentIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
                KeyNavigation.tab: pass
            }

            Item { width: 1; height: 6 * root.u }

            Text {
                text: "ACCESS_CODE"
                color: root.dark
                font.family: root.mono
                font.pixelSize: Math.round(12 * root.u)
                font.bold: true
            }

            TextField {
                id: pass
                width: parent.width
                height: 44 * root.u
                echoMode: TextInput.Password
                focus: true
                color: root.dark
                selectionColor: root.dark
                selectedTextColor: root.cream
                font.family: root.mono
                font.pixelSize: Math.round(16 * root.u)
                leftPadding: 14 * root.u
                verticalAlignment: TextInput.AlignVCenter
                enabled: !root.busy
                background: Rectangle {
                    color: "transparent"
                    border.color: root.dark
                    border.width: pass.activeFocus ? 3 : 2
                }
                onAccepted: root.doLogin()
                KeyNavigation.tab: sessionBox
            }

            Item { width: 1; height: 6 * root.u }

            Text {
                text: "SESSION"
                color: root.dark
                font.family: root.mono
                font.pixelSize: Math.round(12 * root.u)
                font.bold: true
            }

            NierCombo {
                id: sessionBox
                width: parent.width
                scaleU: root.u
                darkColor: root.dark
                creamColor: root.cream
                fontFamily: root.mono
                model: sessionModel
                textRole: "name"
                currentIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
                KeyNavigation.tab: loginBtn
            }

            Item { width: 1; height: 8 * root.u }

            NierButton {
                id: loginBtn
                width: parent.width
                scaleU: root.u
                darkColor: root.dark
                creamColor: root.cream
                fontFamily: root.mono
                primary: true
                text: "[ AUTHENTICATE ]"
                onClicked: root.doLogin()
                KeyNavigation.tab: userBox
            }

            Text {
                width: parent.width
                height: 24 * root.u
                text: root.status
                color: root.status.indexOf("FAILED") >= 0 ? root.alert : root.dark
                font.family: root.mono
                font.pixelSize: Math.round(13 * root.u)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }
    }

    // ---------------------------------------------------------------- power buttons (bottom-right)
    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: 56 * root.u
        anchors.bottomMargin: 48 * root.u
        spacing: 12 * root.u

        NierButton {
            visible: sddm.canSuspend
            scaleU: root.u
            darkColor: root.cream
            creamColor: root.dark
            fontFamily: root.mono
            text: "SUSPEND"
            onClicked: sddm.suspend()
        }
        NierButton {
            visible: sddm.canReboot
            scaleU: root.u
            darkColor: root.cream
            creamColor: root.dark
            fontFamily: root.mono
            text: "REBOOT"
            onClicked: sddm.reboot()
        }
        NierButton {
            visible: sddm.canPowerOff
            scaleU: root.u
            darkColor: root.cream
            creamColor: root.dark
            fontFamily: root.mono
            text: "SHUTDOWN"
            onClicked: sddm.powerOff()
        }
    }

    // ---------------------------------------------------------------- footer (bottom-left)
    Text {
        x: 56 * root.u
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 48 * root.u
        text: "> HOST: " + sddm.hostName + "\n> NO_ERRORS_DETECTED\n[ ALL_SYSTEMS_NOMINAL ]"
        color: root.mid
        font.family: root.mono
        font.pixelSize: Math.round(13 * root.u)
        lineHeight: 1.3
    }

    Component.onCompleted: pass.forceActiveFocus()
}
