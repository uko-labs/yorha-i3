import QtQuick 2.15

// Flat NieR-style button: filled dark when primary, inverts on hover or focus.
Rectangle {
    id: btn

    property string text: ""
    property bool primary: false
    property real scaleU: 1.0
    property color darkColor: "#4a4640"
    property color creamColor: "#d1cdb7"
    property string fontFamily: "JetBrains Mono"

    signal clicked()

    activeFocusOnTab: true
    implicitWidth: label.implicitWidth + 36 * scaleU
    implicitHeight: 42 * scaleU

    readonly property bool inverted: area.containsMouse || btn.activeFocus
    readonly property bool filled: primary ? !inverted : inverted

    color: filled ? darkColor : "transparent"
    border.color: darkColor
    border.width: 2

    Text {
        id: label
        anchors.centerIn: parent
        text: btn.text
        color: btn.filled ? btn.creamColor : btn.darkColor
        font.family: btn.fontFamily
        font.pixelSize: Math.round(14 * btn.scaleU)
        font.bold: true
    }

    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        onClicked: btn.clicked()
    }

    Keys.onReturnPressed: btn.clicked()
    Keys.onEnterPressed: btn.clicked()
    Keys.onSpacePressed: btn.clicked()
}
