import QtQuick 2.15
import QtQuick.Controls 2.15

// ComboBox restyled to match the NieR menu look (follows the standard Qt customization pattern).
ComboBox {
    id: control

    property real scaleU: 1.0
    property color darkColor: "#4a4640"
    property color creamColor: "#d1cdb7"
    property string fontFamily: "JetBrains Mono"

    implicitHeight: 44 * scaleU
    font.family: fontFamily
    font.pixelSize: Math.round(14 * scaleU)

    delegate: ItemDelegate {
        id: item
        width: control.width
        height: 38 * control.scaleU
        highlighted: control.highlightedIndex === index

        contentItem: Text {
            text: model[control.textRole]
            color: item.highlighted ? control.creamColor : control.darkColor
            font: control.font
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            leftPadding: 6
        }

        background: Rectangle {
            color: item.highlighted ? control.darkColor : control.creamColor
        }
    }

    indicator: Text {
        x: control.width - width - 14 * control.scaleU
        y: (control.height - height) / 2
        text: "v"
        color: control.darkColor
        font.family: control.fontFamily
        font.pixelSize: Math.round(14 * control.scaleU)
        font.bold: true
    }

    contentItem: Text {
        leftPadding: 14 * control.scaleU
        rightPadding: control.indicator.width + 20 * control.scaleU
        text: control.displayText
        color: control.darkColor
        font: control.font
        elide: Text.ElideRight
        verticalAlignment: Text.AlignVCenter
    }

    background: Rectangle {
        color: "transparent"
        border.color: control.darkColor
        border.width: control.activeFocus || control.popup.visible ? 3 : 2
    }

    popup: Popup {
        y: control.height - 1
        width: control.width
        implicitHeight: contentItem.implicitHeight
        padding: 0

        contentItem: ListView {
            clip: true
            implicitHeight: Math.min(contentHeight, 240 * control.scaleU)
            model: control.popup.visible ? control.delegateModel : null
            currentIndex: control.highlightedIndex
        }

        background: Rectangle {
            color: control.creamColor
            border.color: control.darkColor
            border.width: 2
        }
    }
}
