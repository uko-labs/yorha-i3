#!/usr/bin/env bash
# Build the YoRHa i3 live ISO. Run on a Fedora machine (or VM) with ~20 GB free and internet.
#   ./build-iso.sh
#   FEDORA_VER=43 ./build-iso.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. /etc/os-release
VER="${FEDORA_VER:-$VERSION_ID}"
WORK="${WORK:-$HOME/yorha-i3-build}"

# GitHub Actions runs this script as root inside its Fedora container.
# Local builds still use sudo when launched by an ordinary user.
if [ "$(id -u)" -eq 0 ]; then
  SUDO=()
else
  SUDO=(sudo)
fi

echo ">> Installing build tools"
"${SUDO[@]}" dnf install -y livecd-tools pykickstart git curl tar

if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" = "Enforcing" ]; then
  echo ">> SELinux is Enforcing; livecd-creator usually needs it permissive while building."
  echo "   Run: sudo setenforce 0   (then re-run this script; it resets on reboot)"
  exit 1
fi

mkdir -p "$WORK"
cd "$WORK"

if [ ! -d fedora-kickstarts ]; then
  echo ">> Fetching Fedora kickstarts (branch f$VER)"
  # Pagure's HTTP transport does not support shallow cloning.
  git clone --branch "f$VER" https://pagure.io/fedora-kickstarts.git
fi
cd fedora-kickstarts

if [ ! -f fedora-live-i3.ks ]; then
  echo "fedora-live-i3.ks not found for Fedora $VER. Available live kickstarts:" >&2
  ls fedora-live-*.ks >&2
  exit 1
fi

echo ">> Staging payload"
STAGE="$WORK/stage"
rm -rf "$STAGE"
mkdir -p "$STAGE"
# Only etc/ and usr/ are part of this kit; anything else under payload/ is ignored.
cp -a "$HERE/payload/etc" "$HERE/payload/usr" "$STAGE/"

WALL="$HERE/assets/wallpaper.png"
[ -f "$WALL" ] || WALL="$HERE/assets/default-wallpaper.png"
[ -f "$WALL" ] || { echo "No wallpaper found in assets/" >&2; exit 1; }
cp "$WALL" "$STAGE/usr/share/yorha/wallpaper.png"
cp "$WALL" "$STAGE/usr/share/sddm/themes/yorha/background.png"

tar -C "$STAGE" -czf "$WORK/payload.tar.gz" etc usr

echo ">> Generating kickstart"
cp "$HERE/yorha-i3.ks" yorha-final.ks
{
  echo
  echo "%post --erroronfail"
  echo "base64 -d <<'YORHA_PAYLOAD_B64' | tar -xz -C /"
  base64 -w76 "$WORK/payload.tar.gz"
  echo "YORHA_PAYLOAD_B64"
  cat <<'EOF'

# Show only the plain i3 session in the login screen's session list
rm -f /usr/share/xsessions/i3-with-shmlog.desktop

# Swap LightDM for SDDM so the NieR login theme is used
systemctl disable lightdm.service 2>/dev/null || true
systemctl enable sddm.service

# Make sure the theme files are readable by the sddm user
chmod -R a+rX /usr/share/sddm/themes/yorha /usr/share/yorha
%end
EOF
} >> yorha-final.ks

echo ">> Flattening kickstart"
ksflatten --config yorha-final.ks -o yorha-flat.ks

echo ">> Building ISO (this takes a while)"
"${SUDO[@]}" livecd-creator --verbose --config=yorha-flat.ks \
  --fslabel="YoRHa-i3-$VER" --releasever="$VER" --cache=/var/cache/live

echo ">> Done. The ISO is in: $(pwd)"
ls -lh ./*.iso
